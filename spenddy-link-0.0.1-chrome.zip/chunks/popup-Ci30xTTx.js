(function(){const t=document.createElement("link").relList;if(t&&t.supports&&t.supports("modulepreload"))return;for(const e of document.querySelectorAll('link[rel="modulepreload"]'))r(e);new MutationObserver(e=>{for(const o of e)if(o.type==="childList")for(const i of o.addedNodes)i.tagName==="LINK"&&i.rel==="modulepreload"&&r(i)}).observe(document,{childList:!0,subtree:!0});function s(e){const o={};return e.integrity&&(o.integrity=e.integrity),e.referrerPolicy&&(o.referrerPolicy=e.referrerPolicy),e.crossOrigin==="use-credentials"?o.credentials="include":e.crossOrigin==="anonymous"?o.credentials="omit":o.credentials="same-origin",o}function r(e){if(e.ep)return;e.ep=!0;const o=s(e);fetch(e.href,o)}})();try{}catch(n){console.error("[wxt] Failed to initialize plugins",n)}const c=document.querySelector("#app");function d(){c.innerHTML=`
    <img src="icon/logo.png" class="brand-logo" width="64" alt="Spenddy logo" />
    <div class="status disconnected">
      <span class="icon">🔌</span>
      <span class="label">Disconnected</span>
    </div>
    <ol class="steps">
      <li>Open Swiggy.com</li>
      <li>Log in to your account</li>
      <li>Reopen this extension popup</li>
    </ol>
    <button id="open-swiggy">Open Swiggy</button>
  `,document.querySelector("#open-swiggy").addEventListener("click",()=>{chrome.tabs.create({url:"https://www.swiggy.com/"})})}function l(n,t,s=!1,r=0){if(!n&&!s)c.innerHTML=`
      <img src="icon/logo.png" class="brand-logo" width="64" alt="Spenddy logo" />
      <div class="status connected">
        <span class="icon">🔌</span>
        <span class="label">Connected</span>
      </div>
      <p class="success">Connected! Fetch your order history.</p>
      <button id="fetch-orders">Fetch Order Data</button>
    `,document.querySelector("#fetch-orders").addEventListener("click",()=>{chrome.tabs.query({url:"*://*.swiggy.com/*"},e=>{e.length>0&&e[0].id?chrome.tabs.sendMessage(e[0].id,{type:"fetch_orders"}):alert("Open Swiggy.com tab and stay logged in before fetching orders.")})});else if(s)c.innerHTML=`
      <img src="icon/logo.png" class="brand-logo" width="64" alt="Spenddy logo" />
      <div class="status connected">
        <span class="icon">🔌</span>
        <span class="label">Connected</span>
      </div>
      <p class="success">Fetching orders... ${r} fetched</p>
      <p>Please wait until completion.</p>
    `;else{const e=t?`<p class="latest">Last order: ${t}</p>`:"";c.innerHTML=`
      <img src="icon/logo.png" class="brand-logo" width="64" alt="Spenddy logo" />
      <div class="status connected">
        <span class="icon">🔌</span>
        <span class="label">Connected</span>
      </div>
      <p class="success">Order data captured!</p>
      ${e}
      <button id="open-spenddy">Go to Spenddy</button>
    `,document.querySelector("#open-spenddy").addEventListener("click",()=>{chrome.tabs.create({url:"https://spenddy.ikr.one/"})})}}chrome.storage.local.get(["swiggyConnected","ordersFetched","latestOrderTime","fetching","progressCount"],n=>{const{swiggyConnected:t,ordersFetched:s,latestOrderTime:r,fetching:e,progressCount:o}=n;t?l(!!s,r,!!e,o??0):d()});chrome.storage.onChanged.addListener(n=>{(n.swiggyConnected||n.ordersFetched||n.latestOrderTime||n.fetching||n.progressCount)&&chrome.storage.local.get(["swiggyConnected","ordersFetched","latestOrderTime","fetching","progressCount"],t=>{t.swiggyConnected?l(!!t.ordersFetched,t.latestOrderTime,!!t.fetching,t.progressCount??0):d()})});
